/************************************************************************

     jk_map.c
     
     Conjecture

************************************************************************/


#include <math.h>
#include <stdio.h>

void jk_map(float delta_t, float tnet_des, int* jake)

{

     float eng_map(float, float, int, int);    
     


}
